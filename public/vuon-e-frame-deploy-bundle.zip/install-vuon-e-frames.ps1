param(
  [string]$Repo = '.',
  [string]$Archive = './vuon-e-frame-integration.zip',
  [switch]$Push,
  [switch]$ApproveUnreviewedFrames
)
$ErrorActionPreference = 'Stop'
if (-not (Test-Path $Archive)) { throw "Missing archive: $Archive" }
$repoPath = (Resolve-Path $Repo).Path
if (-not (Test-Path (Join-Path $repoPath 'package.json'))) { throw "Not a Next.js project: $repoPath" }
$temporary = Join-Path ([System.IO.Path]::GetTempPath()) ('vuon-e-frames-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $temporary | Out-Null
try {
  Expand-Archive -LiteralPath $Archive -DestinationPath $temporary -Force
  $source = Join-Path $temporary 'public/art'
  $manifestFile = Join-Path $source 'manifest.json'
  if (-not (Test-Path $manifestFile)) { throw 'Missing manifest in archive' }
  $manifest = Get-Content $manifestFile -Raw | ConvertFrom-Json
  $total = 0
  foreach ($actor in @('employee','dog','cat')) {
    foreach ($action in $manifest.$actor.PSObject.Properties) {
      $count = [int]$action.Value
      for ($i = 0; $i -lt $count; $i++) {
        $name = '{0:D2}.webp' -f $i
        $path = Join-Path $source "frames/$actor/$($action.Name)/$name"
        if (-not (Test-Path $path)) { throw "Missing $path" }
        $bytes = [System.IO.File]::ReadAllBytes($path)
        if ($bytes.Length -lt 100 -or [Text.Encoding]::ASCII.GetString($bytes,0,4) -ne 'RIFF' -or [Text.Encoding]::ASCII.GetString($bytes,8,4) -ne 'WEBP') { throw "Invalid WebP: $path" }
        $total++
      }
    }
  }
  Write-Host "Validated $total WebP files for three actors." -ForegroundColor Green
  if (-not $ApproveUnreviewedFrames) {
    Write-Warning 'Frames came from automated crops of a composite contact sheet; quality and alignment were NOT approved. Nothing copied or pushed.'
    Write-Host 'Review frames manually first. Re-run with -ApproveUnreviewedFrames to install and optionally -Push to commit/push.'
    exit 0
  }
  $target = Join-Path $repoPath 'public/art'
  New-Item -ItemType Directory -Path $target -Force | Out-Null
  Copy-Item -Path (Join-Path $source 'frames') -Destination $target -Recurse -Force
  Copy-Item -Path $manifestFile -Destination (Join-Path $target 'manifest.json') -Force
  Push-Location $repoPath
  try {
    npm run test:frames
    if ($LASTEXITCODE -ne 0) { throw 'Frame validation failed' }
    if ($Push) {
      git add public/art/frames public/art/manifest.json
      git commit -m 'feat(2d): install Vườn É character animation frames'
      if ($LASTEXITCODE -ne 0) { throw 'Commit failed' }
      git push origin HEAD:main
      if ($LASTEXITCODE -ne 0) { throw 'Push failed' }
      Write-Host 'Pushed frame pack to main.' -ForegroundColor Green
    }
  } finally { Pop-Location }
} finally { Remove-Item -LiteralPath $temporary -Recurse -Force -ErrorAction SilentlyContinue }
